
# coding: utf-8


import numpy as np
import pandas as pd
import xgboost as xgb
import gc

# -*- coding: UTF-8 -*-
from sklearn.cross_validation import KFold
import pandas as pd
import numpy as np
from scipy import sparse
import xgboost
import lightgbm
import random
from sklearn.ensemble import RandomForestClassifier,AdaBoostClassifier,GradientBoostingClassifier,ExtraTreesClassifier
from sklearn.ensemble import RandomForestRegressor,AdaBoostRegressor,GradientBoostingRegressor,ExtraTreesRegressor
from sklearn.multiclass import OneVsRestClassifier
from sklearn.linear_model import LinearRegression,LogisticRegression
from sklearn.svm import LinearSVC,SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import log_loss,mean_absolute_error,mean_squared_error
from sklearn import preprocessing
from sklearn.preprocessing import MinMaxScaler,Normalizer,StandardScaler
from sklearn.decomposition import PCA
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer,HashingVectorizer
from sklearn.naive_bayes import MultinomialNB,GaussianNB


a =0.65236
b = 35.6339

a1 = 0.886429933901
b1 = 33.7338515207

a2= 0.757546152448
b2 =23.0522742968

a3 = 0.708384297278
b3 = 19.9145982725

a4 = 0.8256411669
b4 = 29.2263017215

a5 = 0.735076483208
b5 = 19.3139758324

age_a = 31.5895814697
age_b = 1274.60667472

res_a = 202.153145055
res_b = 7070.53936983

pos_con_a = 0.57895
pos_con_b = 35.294455

def small_date(data):
    col = data.columns
    for name in col:
        if(name.find('ratio')!=-1):

            print (data[data[name]==np.inf][name])
            data[name] = data[name].map(lambda x:(int)(x*1000))
    return data

def BayesianSmoothing(data):
    data['pos_click_ratio'] = (data['pos_click_use']+a)/(data['pos_click']+a+b)

    data['creative_click_ratio'] = (data['creative_click_use'] + a1) / (data['creative_click'] + a1 + b1)

    data['cam_click_ratio'] = (data['cam_click_use'] + a2) / (data['cam_click'] + a2 + b2)

    data['advertiser_click_ratio'] = (data['advertiser_click_use'] + a3) / (data['advertiser_click'] + a3 + b3)

    data['ad_click_ratio'] = (data['ad_click_use'] + a4) / (data['ad_click'] + a4 + b4)

    data['app_click_ratio'] = (data['app_click_use'] + a5) / (data['app_click'] + a5 + b5)

    data['age_ratio'] = (data['age_click_use'] + age_a) / (data['age_click'] + age_a +age_b)

    data['residence_ratio'] = (data['residence_click_use'] + res_a) / (data['residence_click'] + res_a +res_b)

    data['rank'] = data['user_day_click_this_creativeID'] - data['user_day_this_creativeID_rank1']
    del data['app_number']
    del data['userID']
    return data


def get_app_mis(cnt):
    data1 = pd.read_csv('./cache/26app.csv')
    data2 = pd.read_csv('./cache/27app.csv')
    data3 = pd.read_csv('./cache/28app.csv')
    data = pd.concat([data1,data2,data3],ignore_index=True)
    data = data.sort_values(by='ratio',ascending = True)
    print(data)
    data = data.drop_duplicates(['appID'])
    return data[data.ratio>=cnt][['appID']]
########################################################################################################


def get_data():


    train21 =  pd.read_csv('./train/final_21000000.csv')
    train21 = BayesianSmoothing(train21.copy())

    train22 = pd.read_csv('./train/final_22000000.csv')
    train22 = BayesianSmoothing(train22.copy())

    train23 =  pd.read_csv('./train/final_23000000.csv')
    train23 = BayesianSmoothing(train23.copy())

    train24 =  pd.read_csv('./train/final_24000000.csv')
    train24 = BayesianSmoothing(train24.copy())

    train25 = pd.read_csv('./train/final_25000000.csv')
    train25 = BayesianSmoothing(train25.copy())

    data3 =  pd.read_csv('./train/final_26000000.csv')
    data3 = BayesianSmoothing(data3.copy())

    data4 =  pd.read_csv('./train/final_27000000.csv')
    data4 = BayesianSmoothing(data4.copy())

    train7 = pd.read_csv('./train/final_28000000.csv')
    train7 = BayesianSmoothing(train7.copy())

    train8 = pd.read_csv('./train/final_29000000.csv')
    train8 = BayesianSmoothing(train8.copy())

    data30 = pd.read_csv('./train/final_30000000.csv')
    data30 = BayesianSmoothing(data30.copy())

    ac = get_app_mis(0.10)
    data30 = data30[~data30.appID.isin(ac['appID'])]
    print(len(data30))
    print(data30[data30.appID.isin(ac)])   

    train = pd.concat([train21,train22,train23,train24,train25,data3,data4,train7, train8,data30], ignore_index=True)

    valid = pd.read_csv('./train/final_31000000.csv')
    valid = BayesianSmoothing(valid.copy())

    x_train = train.drop(['conversionTime', 'clickTime',\
                'appPlatform','haveBaby','telecomsOperator','marriageStatus','sitesetID',\
                'gender','education','connectionType','positionType','residence','creativeID','adID',\
                'camgaignID','advertiserID','appCategory','positionID','appID','hometown'], axis=1)
    # x_train = pd.DataFrame(x_train)
    # y_train = train['label']
    x_valid = valid.drop(['instanceID', 'clickTime',\
                'appPlatform','haveBaby','telecomsOperator','marriageStatus','sitesetID',\
                'gender','education','connectionType','positionType','residence','creativeID','adID',\
                'camgaignID','advertiserID','appCategory','positionID','appID','hometown'], axis=1)
    # x_valid = pd.DataFrame(x_valid)

    where_are_nan = np.isnan(x_train)
    where_are_inf = np.isinf(x_train)
    x_train[where_are_nan] = 0
    x_train[where_are_inf] = 0
    where_are_nan = np.isnan(x_valid)
    where_are_inf = np.isinf(x_valid)
    x_valid[where_are_nan] = 0
    x_valid[where_are_inf] = 0

    # x_train = pd.DataFrame(x_train)
    # y_train = pd.DataFrame(y_train)
    # x_valid = pd.DataFrame(x_valid)
    return x_train,x_valid




'输入的train只包含要转换的特征和label，而test也就是31号的数据集只包含与train相同的要转换的特征'


def get_xgb_features(train,test):
    dtrain = xgb.DMatrix(train.drop(['label'],axis = 1),train['label'])
    dtest = xgb.DMatrix(test.drop(['label'],axis = 1))
    
    param = {
            'objective': 'binary:logistic',
            'eta': 0.5,
           # 'colsample_bytree': 0.886,
            #'min_child_weight': 2,
           'max_depth': 6,
           # 'subsample': 0.886,
            #'alpha': 10,
            #'gamma': 30,
           # 'lambda': 1,
            'silent': 0,
            'verbose_eval': True,
           # 'nthread': 8,
            'eval_metric': 'logloss',
           # 'scale_pos_weight': 10,
            'seed': 201703,
            'missing': -1,
            #'max_leaves':16
    }
    num_round = 50
    plst = list(param.items())
    #plst += [('eval_metric', 'logloss')]
    evallist = [(dtrain, 'train')]#,(dtest,'test')
    
    model=xgb.train(plst, dtrain, num_round, evallist)

    train_xgb_feature = pd.DataFrame(model.predict(dtrain,pred_leaf=True))
    test_xgb_feature = pd.DataFrame(model.predict(dtest,pred_leaf=True))
    return train_xgb_feature, test_xgb_feature


    # print(train_xgb_feature)
    # num_train = train_xgb_feature.shape[0]
    # num_test = test_xgb_feature.shape[0]
    # xgb_code = pd.concat([train_xgb_feature,test_xgb_feature])
    # xgb_code_dummy = pd.DataFrame()
    # for i in range(7):
    #     t = pd.get_dummies(xgb_code[i])
    #     t = t.add_suffix('_tree' + str(i) + '_xgb_code')
    #     xgb_code_dummy = pd.concat([xgb_code_dummy, t], axis=1)
    # xgb_code_dummy_train = xgb_code_dummy.iloc[0:num_train,:]
    # xgb_code_dummy_test = xgb_code_dummy.iloc[num_train:,:]
    # del dtest,dtrain,model,test_xgb_feature,train_xgb_feature,xgb_code_dummy
    # gc.collect()
    # return xgb_code_dummy_train,xgb_code_dummy_test


if __name__ == '__main__':
    train, test = get_data()
    train_xgb_feature,test_xgb_feature = get_xgb_features(train,test)
    train_xgb_feature.to_csv('./cache/train_xgb_feature_10.csv', index=False)
    test_xgb_feature.to_csv('./cache/test_xgb_feature_31.csv', index=False)
