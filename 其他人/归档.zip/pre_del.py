# -*- coding: UTF-8 -*-
import time
from datetime import datetime
from datetime import timedelta
import pandas as pd
import pickle
import os
import math
import numpy as np
import xgboost
user_path = './data/user.csv'
app_path = './data/app_categories.csv'
ad_path = './data/ad.csv'
pos_path = './data/position.csv'
train_path = './data/train.csv'
test_path = './data/test.csv'
app_action = './data/user_app_actions.csv'
app_install = './data/user_installedapps.csv'
ad_con = './new.csv'


def cal(x):
    s = list(x)
    s.sort()
    return s[(int)(len(s)/2)]

fun = lambda x:(int)(x[0:-6])*1440+(int)(x[2:-4])*60+(int)(x[4:-2])
ad = pd.read_csv(ad_path)
app_in = pd.read_csv(app_install)



data = pd.read_csv(train_path,dtype={'clickTime': np.str,'conversionTime': np.str})

data = data[data.label==1]
#data = data.sort_values(by=['creativeID','clickTime'])

data = pd.merge(data,ad,on='creativeID',how='left')


data1 = data.groupby('advertiserID').size()
data1 = data1.reset_index()
data1.columns =['advertiserID','number']


data['gap'] = data.conversionTime.map(fun)-data.clickTime.map(fun)


data = data.groupby('advertiserID')['gap'].apply(cal)
data = data.reset_index()
data.columns = ['advertiserID','midnum']
data = data.sort_values(by='midnum',ascending=False)
data = pd.merge(data,data1,on='advertiserID')
data.to_csv('./cache/adver.csv',index=False)
print(data)


data = data.reset_index(drop = True)
data = data[data.index<=30]

data['flag'] = data.index.map(lambda x:2 if(x<=17) else 1)
data = data[data.number>=10]
data = data.reset_index(drop  = True)
data.to_csv('./cache/new.csv',index = False)
print (data)
