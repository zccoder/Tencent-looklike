# TencentSPA02-PreA
第二届腾讯社交广告算法大赛初赛A榜0.753

代码简洁清晰易懂，就不写注释啦。。。

提供FFM模型及各种NN模型，如下图所示：

![models](https://github.com/jiarenyf/TencentSPA02-PreA/raw/master/datas/models.png)

