#!/bin/bash


./ffm-train -p ../cache/ffm_test0.ffm -t 50 -s 24 --auto-stop ../cache/ffm_train0.ffm model0
./ffm-train -p ../cache/ffm_test1.ffm -t 50 -s 24 --auto-stop ../cache/ffm_train1.ffm model1
./ffm-train -p ../cache/ffm_test2.ffm -t 50 -s 24 --auto-stop ../cache/ffm_train2.ffm model2
./ffm-train -p ../cache/ffm_test3.ffm -t 50 -s 24 --auto-stop ../cache/ffm_train3.ffm model3
./ffm-train -p ../cache/ffm_test4.ffm -t 50 -s 24 --auto-stop ../cache/ffm_train4.ffm model4
./ffm-predict ../cache/test_31.ffm model0 ../cache/ffmtest0.out
./ffm-predict ../cache/test_31.ffm model1 ../cache/ffmtest1.out
./ffm-predict ../cache/test_31.ffm model2 ../cache/ffmtest2.out
./ffm-predict ../cache/test_31.ffm model3 ../cache/ffmtest3.out
./ffm-predict ../cache/test_31.ffm model4 ../cache/ffmtest4.out
./ffm-predict ../cache/ffm_test0.ffm model0 ../cache/ffmtrain0.out
./ffm-predict ../cache/ffm_test1.ffm model1 ../cache/ffmtrain1.out
./ffm-predict ../cache/ffm_test2.ffm model2 ../cache/ffmtrain2.out
./ffm-predict ../cache/ffm_test3.ffm model3 ../cache/ffmtrain3.out
./ffm-predict ../cache/ffm_test4.ffm model4 ../cache/ffmtrain4.out




