# -*- encoding:utf-8 -*-
import pandas as pd
import numpy as np
import scipy as sp
import math

inverse_logit = lambda x: math.log(x/(1.0-x))
logit = lambda x: 1.0/(1+math.exp(-x))

sub = pd.read_csv('./cache/test_stacking_10_2ceng_lgb_addffm.csv')
sub['instanceID'] = sub.index + 1
sub.columns=['prob', 'instanceID']
intercept = inverse_logit(np.mean(sub['prob'])) - inverse_logit(0.027209313502176185)
sub['prob1'] = sub['prob'].apply(inverse_logit) - intercept
sub['prob1'] = sub['prob1'].apply(logit)
sub[['instanceID', 'prob1']].to_csv('submission.csv', index=False)