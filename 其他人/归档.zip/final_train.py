import time
import pandas as pd
import pickle
import os
from datetime import datetime,timedelta
from sklearn.ensemble import GradientBoostingClassifier
import random
import xgboost as xgb
import numpy as np
from sklearn.model_selection import train_test_split
from operator import itemgetter
import operator
from sklearn.model_selection import KFold
import scipy as sp
import gc

a =0.65236
b = 35.6339

a1 = 0.886429933901
b1 = 33.7338515207

a2= 0.757546152448
b2 =23.0522742968

a3 = 0.708384297278
b3 = 19.9145982725

a4 = 0.8256411669
b4 = 29.2263017215

a5 = 0.735076483208
b5 = 19.3139758324

age_a = 31.5895814697
age_b = 1274.60667472

res_a = 202.153145055
res_b = 7070.53936983

pos_con_a = 0.57895
pos_con_b = 35.294455
def BayesianSmoothing(data):
    data['pos_click_ratio'] = (data['pos_click_use']+a)/(data['pos_click']+a+b)

    data['creative_click_ratio'] = (data['creative_click_use'] + a1) / (data['creative_click'] + a1 + b1)

    data['cam_click_ratio'] = (data['cam_click_use'] + a2) / (data['cam_click'] + a2 + b2)

    data['advertiser_click_ratio'] = (data['advertiser_click_use'] + a3) / (data['advertiser_click'] + a3 + b3)

    data['ad_click_ratio'] = (data['ad_click_use'] + a4) / (data['ad_click'] + a4 + b4)

    data['app_click_ratio'] = (data['app_click_use'] + a5) / (data['app_click'] + a5 + b5)

    data['age_ratio'] = (data['age_click_use'] + age_a) / (data['age_click'] + age_a +age_b)

    data['residence_ratio'] = (data['residence_click_use'] + res_a) / (data['residence_click'] + res_a +res_b)

    data['rank'] = data['user_day_click_this_creativeID'] - data['user_day_this_creativeID_rank1']
    del data['app_number']
    del data['userID']
    return data
def get_app_mis(cnt):
    data1 = pd.read_csv('./cache/26app.csv')
    data2 = pd.read_csv('./cache/27app.csv')
    data3 = pd.read_csv('./cache/28app.csv')
    data = pd.concat([data1,data2,data3],ignore_index=True)
    data = data.sort_values(by='ratio',ascending = True)
    print(data)
    data = data.drop_duplicates(['appID'])
    return data[data.ratio>=cnt][['appID']]
def get_data():
        train21 = pd.read_csv('./train/final_21000000.csv')
        train21 = BayesianSmoothing(train21.copy())

        train22 = pd.read_csv('./train/final_22000000.csv')
        train22 = BayesianSmoothing(train22.copy())

        train23 = pd.read_csv('./train/final_23000000.csv')
        train23 = BayesianSmoothing(train23.copy())

        train24 = pd.read_csv('./train/final_24000000.csv')
        train24 = BayesianSmoothing(train24.copy())

        train25 = pd.read_csv('./train/final_25000000.csv')
        train25 = BayesianSmoothing(train25.copy())

        data3 = pd.read_csv('./train/final_26000000.csv')
        data3 = BayesianSmoothing(data3.copy())

        data4 = pd.read_csv('./train/final_27000000.csv')
        data4 = BayesianSmoothing(data4.copy())

        train7 = pd.read_csv('./train/final_28000000.csv')
        train7 = BayesianSmoothing(train7.copy())

        train8 = pd.read_csv('./train/final_29000000.csv')
        train8 = BayesianSmoothing(train8.copy())

        data30 = pd.read_csv('./train/final_30000000.csv')
        data30 = BayesianSmoothing(data30.copy())

        ac = get_app_mis(0.10)
        data30 = data30[~data30.appID.isin(ac['appID'])]
        print(len(data30))
        print(data30[data30.appID.isin(ac)])
       # train = pd.concat([data30],
        #                  ignore_index=True)
        train = pd.concat([train21, train22, train23, train24, train25, data3, data4, train7, train8, data30],
                          ignore_index=True)

        valid = pd.read_csv('./train/final_31000000.csv')
        valid = BayesianSmoothing(valid.copy())
        return train,valid
def xgb_train(number):
    print(number)
  #  print(111)
    final_train,final_test = get_data()

    id1 = pd.read_csv('./cache/train'+str(number)+'.csv')
    id2 =  pd.read_csv('./cache/test'+str(number)+'.csv')

    train_data = final_train[final_train.index.isin(id1['id'])]
    test_data = final_train[~final_train.index.isin(id1['id'])]

    # train_data.to_csv('./6.25/train625.csv',index = False)
    #
    #
    # test_data.to_csv('./6.25/test625.csv', index=False)

    print(111)
    label1 = train_data['label'].copy()

    del train_data['label']
    del train_data['conversionTime']
    del train_data['clickTime']
    training_data = train_data.copy()

    label2 = test_data['label'].copy()
    del test_data['conversionTime']
    del test_data['label']
    del test_data['clickTime']
    sub_trainning_data = test_data.copy()

    del train_data
    del test_data
    gc.collect()

    features_change = training_data.columns
    features_change = ["%s_%s" % (features_change[i], i) for i in range(len(features_change))]
    training_data.columns = features_change
    sub_trainning_data.columns = features_change

    sub_trainning_data = xgb.DMatrix(sub_trainning_data.values, label=label2)
    training_data = xgb.DMatrix(training_data.values, label=label1)

    param = {
        'objective': 'binary:logistic',
        'eta': 0.05,
        'colsample_bytree': 0.8,
        'subsample': 0.8,
        'silent': 1,
        'verbose_eval': True,
        'eval_metric': 'logloss',
        'seed': 201703,
        'missing': -1
    }
    num_round = 2500
    plst = list(param.items())
    evallist = [(training_data, 'train'), (sub_trainning_data, 'eval')]

    bst = xgb.train(plst, training_data, num_round, evallist)
    y = bst.predict(sub_trainning_data)

    importance = bst.get_fscore()
    importance = sorted(importance.items(), key=operator.itemgetter(1))
    print(importance)

    print(11111)
    res = pd.DataFrame()
    res['id'] = id2.id
    #test_data['instanceID'] = test_data.index+1
    res['prob'] = y

    testdata = final_test
    del testdata['label']
    del testdata['instanceID']
    del testdata['clickTime']
    testdata.columns = features_change
    testdata2 = xgb.DMatrix(testdata.values)
    y = bst.predict(testdata2)
    testdata = pd.DataFrame(testdata)

    testdata['prob'] = y

    #test_data['id'] = test_data.index
    res[['id','prob']].to_csv('./cache/'+str(number)+'res_xgb.csv',index =False)
    testdata[['prob']].to_csv('./cache/'+str(number) + 'final_res_xgb.csv', index=False)

    #print(logloss(label2,y))
xgb_train(0)
xgb_train(1)
xgb_train(2)
xgb_train(3)
xgb_train(4)