import pandas as pd
import lightgbm as lgb
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.preprocessing import OneHotEncoder,LabelEncoder
from scipy import sparse
import os
import numpy as np
import time
import gc
t1=time.time()
'''
user feature
'LBS', 'age', 'appIdAction', 'appIdInstall', 'carrier',
       'consumptionAbility', 'ct', 'education', 'gender', 'house', 'interest1',
       'interest2', 'interest3', 'interest4', 'interest5', 'kw1', 'kw2', 'kw3',
       'marriageStatus', 'os', 'topic1', 'topic2', 'topic3', 'uid'],
      dtype='object'

'''
save_feature=['aid','uid','label','LBS','age','carrier','consumptionAbility','education','gender','house','os','ct','marriageStatus','advertiserId','campaignId', 'creativeId',
       'adCategoryId', 'productId', 'productType','creativeSize']

chusai_addr='/home/flypiggy/Downloads/Shen/echo/tencent_ad/preliminary_contest_data/original'
#ad
ad_feature=pd.read_csv('adFeature.csv')#fusai
ad_feature_chusai=pd.read_csv('%s/adFeature.csv'%chusai_addr)#chusai
mix_adFeature=pd.concat([ad_feature,ad_feature_chusai])
print('ori mix_adFeature shape:',mix_adFeature.shape,'fusai ad_feature shape',ad_feature.shape)
del ad_feature,ad_feature_chusai;gc.collect()

mix_adFeature=mix_adFeature.drop_duplicates()
save_col_name=list(set(list(mix_adFeature))&set(save_feature))
mix_adFeature=mix_adFeature[save_col_name]
print('save_col_name',save_col_name)
print('dup mix_adFeature shape:',mix_adFeature.shape)
print('all time:',time.time()-t1)

#user
user_feature_chusai=pd.read_csv('%s/userFeature.csv'%chusai_addr)#chusai 
user_feature1=pd.read_csv('userFeature1.csv')#fusai 1
user_feature2=pd.read_csv('userFeature2.csv')#fusai 2

mix_user_feature=pd.concat([user_feature1,user_feature2,user_feature_chusai])

#drop duplicates
print('ori mix_user_feature shape:',mix_user_feature.shape)
del user_feature_chusai,user_feature1,user_feature2;gc.collect()

mix_user_feature=mix_user_feature.drop_duplicates()
save_col_name=list(set(list(mix_user_feature))&set(save_feature))
mix_user_feature=mix_user_feature[save_col_name]
print('save_col_name',save_col_name)
print('drop dup mix_user_feature shape:',mix_user_feature.shape)
print('all time:',time.time()-t1)
#-----------------------------------------------------------------------


#train
train=pd.read_csv('train.csv')
train_chusai=pd.read_csv('%s/train.csv'%chusai_addr)#chusai 
mix_train=pd.concat([train,train_chusai])

print('ori mix_train shape:',mix_train.shape,'fusai train shape',train.shape)
del train,train_chusai;gc.collect()

mix_train=mix_train.drop_duplicates()
print('dup mix_train shape:',mix_train.shape)
#-----------------------------------------------------------------------

predict1=pd.read_csv('test1.csv') #change test set
predict2=pd.read_csv('test2.csv') #change test set
predict=pd.concat([predict1,predict2])
del predict1,predict2;gc.collect()


mix_train.loc[mix_train['label']==-1,'label']=0
predict['label']=-1
data=pd.concat([mix_train,predict])
data=pd.merge(data,mix_adFeature,on='aid',how='left')
data=pd.merge(data,mix_user_feature,on='uid',how='left')
data=data.fillna('-1')

print('merge time:',time.time()-t1)
one_hot_feature=['LBS','age','carrier','consumptionAbility','education','gender','house','os','ct','marriageStatus','advertiserId','campaignId', 'creativeId','adCategoryId', 'productId', 'productType','creativeSize']
for feature in one_hot_feature:
    try:
        data[feature] = LabelEncoder().fit_transform(data[feature].apply(int))
    except:
        data[feature] = LabelEncoder().fit_transform(data[feature])

#single_emb=['LBS','age','carrier','consumptionAbility','education','gender','house','os','ct','marriageStatus','advertiserId','campaignId', 'creativeId','adCategoryId', 'productId', #'productType','creativeSize']
#singel_max=[898,5,3,2,7,3,1,4,64,27,209,542,1004,78,88,3,15]

for i in one_hot_feature:
   print(data[i].max())

data.to_csv("./final_embedding_data/sdd_final_onehot_embedding_feature_mix_chusai.csv",header=True,index=False)
print('all time:',time.time()-t1)
