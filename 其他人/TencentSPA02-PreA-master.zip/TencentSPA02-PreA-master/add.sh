#!/bin/bash

cp ../*.py ./ -vu
cp ../store/*.py ./ -vu

