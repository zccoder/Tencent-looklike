#!/usr/bin/python
# -*- coding: UTF-8 -*-
import time
import pandas as pd
import pickle
import os
from datetime import datetime,timedelta
from sklearn.ensemble import GradientBoostingClassifier
import random
import xgboost as xgb
import numpy as np
from sklearn.model_selection import train_test_split
from operator import itemgetter
import operator
from sklearn.model_selection import KFold
import scipy as sp

import numpy
import random
import scipy.special as special

path = '/train/final_'
class BayesianSmoothing(object):
    def __init__(self, alpha, beta):
        self.alpha = alpha
        self.beta = beta

    def sample(self, alpha, beta, num, imp_upperbound):
        sample = numpy.random.beta(alpha, beta, num)
        I = []
        C = []
        for clk_rt in sample:
            imp = random.random() * imp_upperbound
            imp = imp_upperbound
            clk = imp * clk_rt
            I.append(imp)
            C.append(clk)
        return I, C

    def update(self, imps, clks, iter_num, epsilon):
        for i in range(iter_num):
            new_alpha, new_beta = self.__fixed_point_iteration(imps, clks, self.alpha, self.beta)
            if abs(new_alpha-self.alpha)<epsilon and abs(new_beta-self.beta)<epsilon:
                break
            print (new_alpha,new_beta,i)
            self.alpha = new_alpha
            self.beta = new_beta

    def __fixed_point_iteration(self, imps, clks, alpha, beta):
        numerator_alpha = 0.0
        numerator_beta = 0.0
        denominator = 0.0

        for i in range(len(imps)):
            numerator_alpha += (special.digamma(clks[i]+alpha) - special.digamma(alpha))
            numerator_beta += (special.digamma(imps[i]-clks[i]+beta) - special.digamma(beta))
            denominator += (special.digamma(imps[i]+alpha+beta) - special.digamma(alpha+beta))

        return alpha*(numerator_alpha/denominator), beta*(numerator_beta/denominator)


def test():
    data = pd.read_csv(path + '29000000.csv')
    data['appCategory_click'] = data['appCategory_click'].fillna(0)
    data['appCategory_use'] = data['appCategory_use'].fillna(0)
  #  data['appCategory_click']*=12
#    data['appCategory_use']*=12
    data = data[data.appCategory_click!=0]
    data = data.drop_duplicates(['appCategory'])
    I = list(data['appCategory_click'])
    C = list(data['appCategory_use'])
    bs = BayesianSmoothing(1, 1)
   # I, C = bs.sample(500, 500, 1000, 10000)
    print (I, C)
    bs.update(I, C, 1000000, 0.0000000001)
    print (bs.alpha, bs.beta)




if __name__ == '__main__':
    test()
	#r=(C + alpha) / (I + alpha + beta)