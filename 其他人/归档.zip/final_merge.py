# -*- coding: UTF-8 -*-
import time
import pandas as pd
import pickle
import os
from datetime import datetime,timedelta
from sklearn.ensemble import GradientBoostingClassifier
import random
import xgboost as xgb
import numpy as np
from sklearn.model_selection import train_test_split
from operator import itemgetter
import operator
from sklearn.model_selection import KFold
import scipy as sp




test0 = pd.read_csv('./cache/test0.csv')
test1 = pd.read_csv('./cache/test1.csv')
test2 = pd.read_csv('./cache/test2.csv')
test3 = pd.read_csv('./cache/test3.csv')
test4 = pd.read_csv('./cache/test4.csv')

ffm_test0 = pd.read_csv('./cache/ffmtrain0.out',names=['prob'])
ffm_test1 = pd.read_csv('./cache/ffmtrain1.out',names=['prob'])
ffm_test2 = pd.read_csv('./cache/ffmtrain2.out',names=['prob'])
ffm_test3 = pd.read_csv('./cache/ffmtrain3.out',names=['prob'])
ffm_test4 = pd.read_csv('./cache/ffmtrain4.out',names=['prob'])
print (ffm_test4)
print (test4)

ffm_test0 = pd.concat([ffm_test0,test0],axis=1)
ffm_test1 = pd.concat([ffm_test1,test1],axis=1)
ffm_test2 = pd.concat([ffm_test2,test2],axis=1)
ffm_test3 = pd.concat([ffm_test3,test3],axis=1)
ffm_test4 = pd.concat([ffm_test4,test4],axis=1)


ffm_test = pd.concat([ffm_test0,ffm_test1,ffm_test2,ffm_test3,ffm_test4],ignore_index=True)

ffm_test = ffm_test.sort_values(by='id')
del ffm_test['id']
ffm_test = ffm_test.reset_index(drop = True)


xgb_test0 = pd.read_csv('./cache/0res_xgb.csv')
xgb_test1 = pd.read_csv('./cache/1res_xgb.csv')
xgb_test2 = pd.read_csv('./cache/2res_xgb.csv')
xgb_test3 = pd.read_csv('./cache/3res_xgb.csv')
xgb_test4 = pd.read_csv('./cache/4res_xgb.csv')

xgb_test = pd.concat([xgb_test0,xgb_test1,xgb_test2,xgb_test3,xgb_test4],ignore_index=True)
xgb_test = xgb_test.sort_values(by='id')
xgb_test = xgb_test.reset_index(drop = True)
del xgb_test['id']

lgb_test = pd.read_csv('./cache/train_stacking_lgb_10.csv')
del lgb_test['label']
lgb_test = lgb_test.reset_index(drop = True)

ffm_test.columns = ['ffm_prob']
xgb_test.columns = ['xgb_prob']
lgb_test.columns = ['lgb_prob']

final_test = pd.concat([ffm_test['ffm_prob'],xgb_test['xgb_prob'],lgb_test['lgb_prob']],axis=1)
print(ffm_test)
final_test.to_csv('./train/final_merge_train_prob_add_ffm.csv',index = False)

ffm_test0 = pd.read_csv('./cache/ffmtest0.out',names=['prob'])
ffm_test0.columns = ['ffm_prob0']

ffm_test1 = pd.read_csv('./cache/ffmtest1.out',names=['prob'])
ffm_test1.columns = ['ffm_prob1']

ffm_test2 = pd.read_csv('./cache/ffmtest2.out',names=['prob'])
ffm_test2.columns = ['ffm_prob2']

ffm_test3 = pd.read_csv('./cache/ffmtest3.out',names=['prob'])
ffm_test3.columns = ['ffm_prob3']

ffm_test4 = pd.read_csv('./cache/ffmtest4.out',names=['prob'])
ffm_test4.columns = ['ffm_prob4']

ffm_test = pd.concat([ffm_test0['ffm_prob0'],ffm_test1['ffm_prob1'],ffm_test2['ffm_prob2'],ffm_test3['ffm_prob3'],ffm_test4['ffm_prob4']],axis=1)
ffm_test['ffm_prob'] = (ffm_test['ffm_prob0']+ffm_test['ffm_prob1']+ffm_test['ffm_prob2']+ffm_test['ffm_prob3']+ffm_test['ffm_prob4'])/5

xgb_test0 = pd.read_csv('./cache/0final_res_xgb.csv')
xgb_test0.columns = ['xgb_prob0']

xgb_test1 = pd.read_csv('./cache/1final_res_xgb.csv')
xgb_test1.columns = ['xgb_prob1']

xgb_test2 = pd.read_csv('./cache/2final_res_xgb.csv')
xgb_test2.columns = ['xgb_prob2']

xgb_test3 = pd.read_csv('./cache/3final_res_xgb.csv')
xgb_test3.columns = ['xgb_prob3']

xgb_test4 = pd.read_csv('./cache/4final_res_xgb.csv')
xgb_test4.columns = ['xgb_prob4']


xgb_test = pd.concat([xgb_test0['xgb_prob0'],xgb_test1['xgb_prob1'],xgb_test2['xgb_prob2'],xgb_test3['xgb_prob3'],xgb_test4['xgb_prob4']],axis=1)
xgb_test['xgb_prob'] = (xgb_test['xgb_prob0']+xgb_test['xgb_prob1']+xgb_test['xgb_prob2']+xgb_test['xgb_prob3']+xgb_test['xgb_prob4'])/5

lgb_test = pd.read_csv('./cache/test_stacking_lgb_10.csv')
lgb_test.columns = ['lgb_prob']

final_test = pd.concat([ffm_test['ffm_prob'],xgb_test['xgb_prob'],lgb_test['lgb_prob']],axis = 1)
final_test.to_csv('./train/final_merge_test_prob_add_ffm.csv',index = False)

