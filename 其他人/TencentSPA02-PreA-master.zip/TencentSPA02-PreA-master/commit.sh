#!/bin/bash

git add * -v
git commit -m "First commit ..."
git push origin master

